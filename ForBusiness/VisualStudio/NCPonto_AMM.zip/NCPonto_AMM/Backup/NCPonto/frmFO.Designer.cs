﻿namespace NCPonto
{
    partial class frmFO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.txtM = new System.Windows.Forms.Button();
            this.txtOk = new System.Windows.Forms.Button();
            this.txt9 = new System.Windows.Forms.Button();
            this.txt8 = new System.Windows.Forms.Button();
            this.txt7 = new System.Windows.Forms.Button();
            this.txt6 = new System.Windows.Forms.Button();
            this.txt5 = new System.Windows.Forms.Button();
            this.txt4 = new System.Windows.Forms.Button();
            this.txt3 = new System.Windows.Forms.Button();
            this.txt2 = new System.Windows.Forms.Button();
            this.txt1 = new System.Windows.Forms.Button();
            this.txt0 = new System.Windows.Forms.Button();
            this.txtFO = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.cmdVoltar = new System.Windows.Forms.Button();
            this.lblTipoMov = new System.Windows.Forms.Label();
            this.lblTurno = new System.Windows.Forms.Label();
            this.dgvTarefas = new System.Windows.Forms.DataGridView();
            this.cmdContinuar = new System.Windows.Forms.Button();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTarefas)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel1
            // 
            this.Panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Panel1.BackColor = System.Drawing.Color.LightSlateGray;
            this.Panel1.Controls.Add(this.txtM);
            this.Panel1.Controls.Add(this.txtOk);
            this.Panel1.Controls.Add(this.txt9);
            this.Panel1.Controls.Add(this.txt8);
            this.Panel1.Controls.Add(this.txt7);
            this.Panel1.Controls.Add(this.txt6);
            this.Panel1.Controls.Add(this.txt5);
            this.Panel1.Controls.Add(this.txt4);
            this.Panel1.Controls.Add(this.txt3);
            this.Panel1.Controls.Add(this.txt2);
            this.Panel1.Controls.Add(this.txt1);
            this.Panel1.Controls.Add(this.txt0);
            this.Panel1.Controls.Add(this.txtFO);
            this.Panel1.Controls.Add(this.Label1);
            this.Panel1.Location = new System.Drawing.Point(732, 72);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(414, 497);
            this.Panel1.TabIndex = 1;
            // 
            // txtM
            // 
            this.txtM.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtM.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtM.Location = new System.Drawing.Point(311, 412);
            this.txtM.Name = "txtM";
            this.txtM.Size = new System.Drawing.Size(96, 72);
            this.txtM.TabIndex = 13;
            this.txtM.Text = "«";
            this.txtM.UseVisualStyleBackColor = true;
            this.txtM.Click += new System.EventHandler(this.txtM_Click);
            // 
            // txtOk
            // 
            this.txtOk.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOk.ForeColor = System.Drawing.Color.Green;
            this.txtOk.Location = new System.Drawing.Point(311, 151);
            this.txtOk.Name = "txtOk";
            this.txtOk.Size = new System.Drawing.Size(96, 246);
            this.txtOk.TabIndex = 12;
            this.txtOk.Text = "OK";
            this.txtOk.UseVisualStyleBackColor = true;
            this.txtOk.Click += new System.EventHandler(this.txtOk_Click);
            // 
            // txt9
            // 
            this.txt9.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt9.ForeColor = System.Drawing.Color.Black;
            this.txt9.Location = new System.Drawing.Point(211, 151);
            this.txt9.Name = "txt9";
            this.txt9.Size = new System.Drawing.Size(92, 72);
            this.txt9.TabIndex = 11;
            this.txt9.Text = "9";
            this.txt9.UseVisualStyleBackColor = true;
            this.txt9.Click += new System.EventHandler(this.txt9_Click);
            // 
            // txt8
            // 
            this.txt8.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt8.ForeColor = System.Drawing.Color.Black;
            this.txt8.Location = new System.Drawing.Point(109, 151);
            this.txt8.Name = "txt8";
            this.txt8.Size = new System.Drawing.Size(92, 72);
            this.txt8.TabIndex = 10;
            this.txt8.Text = "8";
            this.txt8.UseVisualStyleBackColor = true;
            this.txt8.Click += new System.EventHandler(this.txt8_Click);
            // 
            // txt7
            // 
            this.txt7.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt7.ForeColor = System.Drawing.Color.Black;
            this.txt7.Location = new System.Drawing.Point(7, 151);
            this.txt7.Name = "txt7";
            this.txt7.Size = new System.Drawing.Size(92, 72);
            this.txt7.TabIndex = 9;
            this.txt7.Text = "7";
            this.txt7.UseVisualStyleBackColor = true;
            this.txt7.Click += new System.EventHandler(this.txt7_Click);
            // 
            // txt6
            // 
            this.txt6.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt6.ForeColor = System.Drawing.Color.Black;
            this.txt6.Location = new System.Drawing.Point(211, 236);
            this.txt6.Name = "txt6";
            this.txt6.Size = new System.Drawing.Size(92, 72);
            this.txt6.TabIndex = 8;
            this.txt6.Text = "6";
            this.txt6.UseVisualStyleBackColor = true;
            this.txt6.Click += new System.EventHandler(this.txt6_Click);
            // 
            // txt5
            // 
            this.txt5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt5.ForeColor = System.Drawing.Color.Black;
            this.txt5.Location = new System.Drawing.Point(109, 236);
            this.txt5.Name = "txt5";
            this.txt5.Size = new System.Drawing.Size(92, 72);
            this.txt5.TabIndex = 7;
            this.txt5.Text = "5";
            this.txt5.UseVisualStyleBackColor = true;
            this.txt5.Click += new System.EventHandler(this.txt5_Click);
            // 
            // txt4
            // 
            this.txt4.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt4.ForeColor = System.Drawing.Color.Black;
            this.txt4.Location = new System.Drawing.Point(7, 236);
            this.txt4.Name = "txt4";
            this.txt4.Size = new System.Drawing.Size(92, 72);
            this.txt4.TabIndex = 6;
            this.txt4.Text = "4";
            this.txt4.UseVisualStyleBackColor = true;
            this.txt4.Click += new System.EventHandler(this.txt4_Click);
            // 
            // txt3
            // 
            this.txt3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt3.ForeColor = System.Drawing.Color.Black;
            this.txt3.Location = new System.Drawing.Point(211, 325);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(92, 72);
            this.txt3.TabIndex = 5;
            this.txt3.Text = "3";
            this.txt3.UseVisualStyleBackColor = true;
            this.txt3.Click += new System.EventHandler(this.txt3_Click);
            // 
            // txt2
            // 
            this.txt2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt2.ForeColor = System.Drawing.Color.Black;
            this.txt2.Location = new System.Drawing.Point(109, 325);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(92, 72);
            this.txt2.TabIndex = 4;
            this.txt2.Text = "2";
            this.txt2.UseVisualStyleBackColor = true;
            this.txt2.Click += new System.EventHandler(this.txt2_Click);
            // 
            // txt1
            // 
            this.txt1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt1.ForeColor = System.Drawing.Color.Black;
            this.txt1.Location = new System.Drawing.Point(7, 325);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(92, 72);
            this.txt1.TabIndex = 3;
            this.txt1.Text = "1";
            this.txt1.UseVisualStyleBackColor = true;
            this.txt1.Click += new System.EventHandler(this.txt1_Click);
            // 
            // txt0
            // 
            this.txt0.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt0.ForeColor = System.Drawing.Color.Black;
            this.txt0.Location = new System.Drawing.Point(7, 412);
            this.txt0.Name = "txt0";
            this.txt0.Size = new System.Drawing.Size(296, 72);
            this.txt0.TabIndex = 2;
            this.txt0.Text = "0";
            this.txt0.UseVisualStyleBackColor = true;
            this.txt0.Click += new System.EventHandler(this.txt0_Click);
            // 
            // txtFO
            // 
            this.txtFO.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFO.Location = new System.Drawing.Point(12, 51);
            this.txtFO.Name = "txtFO";
            this.txtFO.Size = new System.Drawing.Size(395, 44);
            this.txtFO.TabIndex = 1;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(8, 19);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(145, 20);
            this.Label1.TabIndex = 0;
            this.Label1.Text = "Folha de Obra nº";
            // 
            // cmdVoltar
            // 
            this.cmdVoltar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdVoltar.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdVoltar.Image = global::NCPonto.Properties.Resources.tras;
            this.cmdVoltar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cmdVoltar.Location = new System.Drawing.Point(732, 586);
            this.cmdVoltar.Name = "cmdVoltar";
            this.cmdVoltar.Size = new System.Drawing.Size(414, 141);
            this.cmdVoltar.TabIndex = 3;
            this.cmdVoltar.Text = "Voltar ao início";
            this.cmdVoltar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cmdVoltar.UseVisualStyleBackColor = true;
            this.cmdVoltar.Click += new System.EventHandler(this.cmdVoltar_Click);
            // 
            // lblTipoMov
            // 
            this.lblTipoMov.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoMov.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblTipoMov.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTipoMov.Location = new System.Drawing.Point(12, 20);
            this.lblTipoMov.Name = "lblTipoMov";
            this.lblTipoMov.Size = new System.Drawing.Size(481, 44);
            this.lblTipoMov.TabIndex = 4;
            this.lblTipoMov.Text = "Tipo de Movimento";
            this.lblTipoMov.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTurno
            // 
            this.lblTurno.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTurno.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTurno.ForeColor = System.Drawing.Color.White;
            this.lblTurno.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblTurno.Location = new System.Drawing.Point(752, 9);
            this.lblTurno.Name = "lblTurno";
            this.lblTurno.Size = new System.Drawing.Size(394, 46);
            this.lblTurno.TabIndex = 6;
            this.lblTurno.Tag = "E1";
            this.lblTurno.Text = "Turno da Manhã";
            this.lblTurno.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblTurno.Click += new System.EventHandler(this.lblTurno_Click);
            // 
            // dgvTarefas
            // 
            this.dgvTarefas.AllowUserToAddRows = false;
            this.dgvTarefas.AllowUserToDeleteRows = false;
            this.dgvTarefas.AllowUserToOrderColumns = true;
            this.dgvTarefas.AllowUserToResizeColumns = false;
            this.dgvTarefas.AllowUserToResizeRows = false;
            this.dgvTarefas.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvTarefas.BackgroundColor = System.Drawing.Color.Black;
            this.dgvTarefas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvTarefas.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Trebuchet MS", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTarefas.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvTarefas.ColumnHeadersHeight = 100;
            this.dgvTarefas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvTarefas.ColumnHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Trebuchet MS", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTarefas.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvTarefas.Location = new System.Drawing.Point(19, 72);
            this.dgvTarefas.MultiSelect = false;
            this.dgvTarefas.Name = "dgvTarefas";
            this.dgvTarefas.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTarefas.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvTarefas.RowHeadersVisible = false;
            this.dgvTarefas.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvTarefas.RowTemplate.Height = 40;
            this.dgvTarefas.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvTarefas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTarefas.Size = new System.Drawing.Size(689, 497);
            this.dgvTarefas.TabIndex = 9;
            this.dgvTarefas.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTarefas_CellContentClick);
            // 
            // cmdContinuar
            // 
            this.cmdContinuar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdContinuar.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdContinuar.ForeColor = System.Drawing.Color.Green;
            this.cmdContinuar.Image = global::NCPonto.Properties.Resources.fo;
            this.cmdContinuar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cmdContinuar.Location = new System.Drawing.Point(19, 586);
            this.cmdContinuar.Name = "cmdContinuar";
            this.cmdContinuar.Size = new System.Drawing.Size(689, 141);
            this.cmdContinuar.TabIndex = 10;
            this.cmdContinuar.Text = "Continuar »";
            this.cmdContinuar.UseVisualStyleBackColor = true;
            this.cmdContinuar.Click += new System.EventHandler(this.cmdContinuar_Click);
            // 
            // frmFO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1174, 751);
            this.Controls.Add(this.cmdContinuar);
            this.Controls.Add(this.dgvTarefas);
            this.Controls.Add(this.lblTurno);
            this.Controls.Add(this.lblTipoMov);
            this.Controls.Add(this.cmdVoltar);
            this.Controls.Add(this.Panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmFO";
            this.Text = "frmFO";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmFO_Load);
            this.Activated += new System.EventHandler(this.frmFO_Activated);
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTarefas)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Button txtM;
        internal System.Windows.Forms.Button txtOk;
        internal System.Windows.Forms.Button txt9;
        internal System.Windows.Forms.Button txt8;
        internal System.Windows.Forms.Button txt7;
        internal System.Windows.Forms.Button txt6;
        internal System.Windows.Forms.Button txt5;
        internal System.Windows.Forms.Button txt4;
        internal System.Windows.Forms.Button txt3;
        internal System.Windows.Forms.Button txt2;
        internal System.Windows.Forms.Button txt1;
        internal System.Windows.Forms.Button txt0;
        internal System.Windows.Forms.TextBox txtFO;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Button cmdVoltar;
        private System.Windows.Forms.Label lblTipoMov;
        private System.Windows.Forms.Label lblTurno;
        internal System.Windows.Forms.DataGridView dgvTarefas;
        private System.Windows.Forms.Button cmdContinuar;

    }
}