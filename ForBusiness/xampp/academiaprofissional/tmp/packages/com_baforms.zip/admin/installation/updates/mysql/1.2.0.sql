ALTER TABLE `#__baforms_forms` ADD COLUMN `message_bg_rgba` varchar(255) NOT NULL;
ALTER TABLE `#__baforms_forms` ADD COLUMN `message_color_rgba` varchar(255) NOT NULL;
ALTER TABLE `#__baforms_forms` ADD COLUMN `dialog_color_rgba` varchar(255) NOT NULL;