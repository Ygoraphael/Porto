DROP TABLE IF EXISTS `#__baforms_forms`;
DROP TABLE IF EXISTS `#__baforms_columns`;
DROP TABLE IF EXISTS `#__baforms_items`;
DROP TABLE IF EXISTS `#__baforms_submissions`;
DROP TABLE IF EXISTS `#__baforms_reference`;
DROP TABLE IF EXISTS `#__baforms_api`;
DROP TABLE IF EXISTS `#__baforms_tokens`;