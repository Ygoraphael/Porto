ALTER TABLE `#__baforms_forms` ADD COLUMN `button_font_size` int(5) NOT NULL DEFAULT 14; 
ALTER TABLE `#__baforms_forms` ADD COLUMN `button_border` int(5) NOT NULL DEFAULT 3; 
ALTER TABLE `#__baforms_forms` ADD COLUMN `button_weight` varchar(10) NOT NULL DEFAULT 'normal'; 