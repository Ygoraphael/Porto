ALTER TABLE `#__baforms_forms` ADD COLUMN `submit_embed` text NOT NULL;  
