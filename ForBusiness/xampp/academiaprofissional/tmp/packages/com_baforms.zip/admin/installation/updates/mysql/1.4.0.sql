ALTER TABLE `#__baforms_forms` ADD COLUMN `email_letter` mediumtext NOT NULL; 
ALTER TABLE `#__baforms_forms` ADD COLUMN `display_cart` tinyint(1) NOT NULL DEFAULT 0;